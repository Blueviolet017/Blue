const start_button = document.querySelector('.footer #items');
const desktop = document.querySelector('.desktop');
let attribute = {
	name:'style', 
	value:'background-color:#f0f0f0; position:absolute; width:70px; height:25px; color:#777;font-size: 12px; padding-left:5px;padding-top:8px; font-weight:bold; border:1.4px solid #707070;transition-property:visibility;transition-duration:.3s;transition-delay:.8s;visibility:hidden',
}
/*Code for events that Happen When you click the start button BEGINS here*/
let toggle = new Animator();
let popUp = new Popups();
toggle.toggleSlideDown('.footer #items', ['.area', '.action_center']);
toggle.toggleSlideDown('.desktop', ['.area', '.action_center']);
toggle.fadeIn(".footer #items", ".main-content");
toggle.overlay(['.username', '.accImage'], '.overlay');
toggle.borderHover(['.mailApp', '.internetExplorer', '.photoExplorer', '.people', '.skype', '.xbox', '.camera', '.folder1', '.folder2', '.oneDrive', '.desktop', 
					'.thisPc', '.documents', '.pictures', '.oneNote', '.calendar', '.pcSettings' , '.msStore' , '.msVs']);
tooltip('div', attribute,'.appContainer1', 'Documents', '.documents');
tooltip('div', attribute,'.appContainer1', 'Pictures', '.pictures');
tooltip('div', attribute,'.appContainer1', 'Settings', '.pcSettings');
tooltip('div', attribute,'.appContainer1', 'This Pc', '.thisPc');
tooltip('div', attribute,'.appContainer1', 'Music', '.folder1');
tooltip('div', attribute,'.appContainer1', 'Downloads', '.folder2');
tooltip('div', attribute,'.appContainer1', 'Camera', '.camera');
tooltip('div', attribute,'.appContainer1', 'Games', '.xbox');
signoutPopUp('.accHolder');
popUp.powerBtnPopup('.powerBtnHolder');
popUp.searchPopup('.searchBtnHolder');
/*A function to let the user escape the start button pop-up when he/she presses the escape on the keyboard*/
desktop.addEventListener('click', ()=>{
	let elem = document.querySelector('.signoutPopUp');
	let maincontent = document.querySelector('.main-content');
	let bringBackTaskbarArea = document.querySelector('.area');
	let bringBackTaskbarActionCenter = document.querySelector('.action_center');
	let startButtonRestore = document.querySelector('.footer #items');
	maincontent.style.transitionProperty = "visibility, transform, position";
	maincontent.style.transitionDuration = .2 + 's';
	maincontent.style.transitionDelay = .05 + 's';
	maincontent.style.visibility = 'hidden';
	maincontent.style.position = 'fixed';
	elem.style.visibility = 'hidden';
	maincontent.style.transitionTimingFunction = "linear";
	bringBackTaskbarArea.style.transitionProperty = "background, transform, visibility, opacity";
	bringBackTaskbarArea.style.transitionDuration = .22 + 's';
	bringBackTaskbarArea.style.transitionDelay = .1 + 's';
	bringBackTaskbarArea.style.transform = 'translateY(' + 0 + ')';
	bringBackTaskbarArea.style.visibility = 'visible';
	bringBackTaskbarArea.style.backgroundColor = "#3c301b";
	bringBackTaskbarActionCenter.style.transitionProperty = "background, transform, visibility, opacity";
	bringBackTaskbarActionCenter.style.transitionDuration = .22 + 's';
	bringBackTaskbarActionCenter.style.transitionDelay = .1 + 's';
	bringBackTaskbarActionCenter.style.transform = 'translateY(' + 0 + ')';
	bringBackTaskbarActionCenter.style.visibility = 'visible';
	bringBackTaskbarActionCenter.style.backgroundColor = "#3c301b";
	startButtonRestore.style.opacity = 1;
	startButtonRestore.removeEventListener('mouseover', startButtonObject.startButtonMouseOver);
	startButtonRestore.removeEventListener('mouseout', startButtonObject.startButtonMouseOut);
	startButtonRestore.addEventListener('mouseover', startButtonObject.startButtonNewMouseOver);
	startButtonRestore.addEventListener('mouseout', startButtonObject.startNewButtonMouseOut);	
});
desktop.addEventListener('mouseover', ()=>{
	startButtonObject.startButtonNewMouseOver();
});
desktop.addEventListener('mouseout', ()=>{
	startButtonObject.startNewButtonMouseOut();
});
window.addEventListener('keydown', (e)=>{
	e.preventDefault;
	if(e.keyCode === 27){
		startButtonObject.startButtonNewMouseOver();
	}
});
window.addEventListener('keyup', (e)=>{
	e.preventDefault;
	let maincontent = document.querySelector('.main-content');
	let bringBackTaskbarArea = document.querySelector('.area');
	let bringBackTaskbarActionCenter = document.querySelector('.action_center');
	let startButtonRestore = document.querySelector('.footer #items');
	let elem = document.querySelector('.signoutPopUp');
	let elempowerBtn = document.querySelector('.powerBtnPopup');
	let elemsearchB = document.querySelector('.searchPopup');
	if(e.keyCode === 27){
		if(maincontent.style.visibility === "visible"){
			elem.style.visibility = 'hidden';
			elempowerBtn.style.visibility = 'hidden';
			elemsearchB.style.visibility = 'hidden';
			maincontent.style.transitionProperty = "visibility, transform, position";
			maincontent.style.transitionDuration = .2 + 's';
			maincontent.style.transitionDelay = .05 + 's';
			maincontent.style.visibility = 'hidden';
			maincontent.style.position = 'fixed';
			maincontent.style.transitionTimingFunction = "linear";
			bringBackTaskbarArea.style.transitionProperty = "background, transform, visibility, opacity";
			bringBackTaskbarArea.style.transitionDuration = .22 + 's';
			bringBackTaskbarArea.style.transitionDelay = .1 + 's';
			bringBackTaskbarArea.style.transform = 'translateY(' + 0 + ')';
			bringBackTaskbarArea.style.visibility = 'visible';
			bringBackTaskbarArea.style.backgroundColor = "#3c301b";
			bringBackTaskbarActionCenter.style.transitionProperty = "background, transform, visibility, opacity";
			bringBackTaskbarActionCenter.style.transitionDuration = .22 + 's';
			bringBackTaskbarActionCenter.style.transitionDelay = .1 + 's';
			bringBackTaskbarActionCenter.style.transform = 'translateY(' + 0 + ')';
			bringBackTaskbarActionCenter.style.visibility = 'visible';
			bringBackTaskbarActionCenter.style.backgroundColor = "#3c301b";
			startButtonRestore.style.opacity = 1;
			startButtonRestore.removeEventListener('mouseover', startButtonObject.startButtonMouseOver);
			startButtonRestore.removeEventListener('mouseout', startButtonObject.startButtonMouseOut);
			startButtonRestore.addEventListener('mouseover', startButtonObject.startButtonNewMouseOver);
			startButtonRestore.addEventListener('mouseout', startButtonObject.startNewButtonMouseOut);	
		}
	}
});

/*The methods within this object is used by the event handlers inside the methods of the Animator object*/
let startButtonObject = {
	startButtonMouseOver:function startButtonMouseOver(){
		start_button.style.transitionProperty = "background, opacity";
		start_button.style.transitionDuration = .24 + 's';
		start_button.style.transitionDelay = .2 + 's';
		start_button.style.backgroundColor = "#000";
		start_button.style.opacity = 1;
	},
	startButtonMouseOut:function startButtonMouseOut(){
		start_button.style.transitionProperty = "background, opacity";
		start_button.style.transitionDuration = .17 + 's';
		start_button.style.transitionDelay = .01 + 's';
		start_button.style.opacity = 0;
	},
	startButtonNewMouseOver:function startButtonNewMouseOver(){
		start_button.style.backgroundColor = "#000";
		start_button.style.transitionProperty = "opacity";
		start_button.style.transitionDuration = .24 + 's';
		start_button.style.transitionDelay = .2 + 's';
	},
	startNewButtonMouseOut:function startNewButtonMouseOut(){
		start_button.style.backgroundColor = "#3c301b";
		start_button.style.transitionProperty = "background, opacity";
		start_button.style.transitionDuration = .17 + 's';
		start_button.style.transitionDelay = .01 + 's';
	},
}
	
function Animator(){
	this.overlay = (triggerElement, affectedElement) =>{
		let affElem = document.querySelector(affectedElement); 
		triggerElement.forEach((index, value)=>{
			let elemHandler = document.querySelector(triggerElement[value]);
			elemHandler.addEventListener('mouseover', ()=>{
				if(elemHandler.style.backgroundColor === ""){
					affElem.style.backgroundColor = "ghostwhite";
					affElem.style.opacity = .1;
				}
			});
			elemHandler.addEventListener('mouseout', ()=>{
				affElem.style.backgroundColor = "";
				affElem.style.opacity = "";
			});
		});
	}
	this.toggleSlideDown = function(toggleButton, toggledElement){
		let elemHandler = document.querySelector(toggleButton);
		elemHandler.addEventListener('click', startClick);
		function startClick(){
			for (let i=0; i < toggledElement.length; i++) {
				let elemHandler2 = document.querySelector(toggledElement[i]);
				if(elemHandler2.style.visibility === ""){
					elemHandler2.style.transitionProperty = "background, transform, visibility, opacity";
					elemHandler2.style.transitionDuration = .057 + 's';
					elemHandler2.style.transitionDelay = .09 + 's';
					elemHandler2.style.transform = 'translateY(' + 39 + 'px)';
					elemHandler2.style.visibility = 'hidden';
					elemHandler2.style.backgroundColor = "transparent";
					elemHandler.addEventListener('mouseover', startButtonObject.startButtonMouseOver);
					elemHandler.addEventListener('mouseout', startButtonObject.startButtonMouseOut);
				}
				else if(elemHandler2.style.visibility === "visible"){
					elemHandler2.style.transitionProperty = "background, transform, visibility, opacity";
					elemHandler2.style.transitionDuration = .057 + 's';
					elemHandler2.style.transitionDelay = .09 + 's';
					elemHandler2.style.transform = 'translateY(' + 39 + 'px)';
					elemHandler2.style.visibility = 'hidden';
					elemHandler2.style.backgroundColor = "transparent";
					elemHandler.addEventListener('mouseover', startButtonObject.startButtonMouseOver);
					elemHandler.addEventListener('mouseout', startButtonObject.startButtonMouseOut);
				}
				else if(elemHandler2.style.visibility === "hidden"){
					elemHandler2.style.transitionProperty = "background, transform, visibility, opacity";
					elemHandler2.style.transitionDuration = .22 + 's';
					elemHandler2.style.transitionDelay = .1 + 's';
					elemHandler2.style.transform = 'translateY(' + 0 + ')';
					elemHandler2.style.visibility = 'visible';
					elemHandler2.style.backgroundColor = "#3c301b";
					elemHandler.removeEventListener('mouseover', startButtonObject.startButtonMouseOver);
					elemHandler.removeEventListener('mouseout', startButtonObject.startButtonMouseOut);
					elemHandler.addEventListener('mouseover', startButtonObject.startButtonNewMouseOver);
					elemHandler.addEventListener('mouseout', startButtonObject.startNewButtonMouseOut);	
				}
				
			}	
		}
	}
	this.fadeIn = function (triggerElement, elementToFade){
		let elemHandler = document.querySelector(elementToFade);
		let triggerHandler = document.querySelector(triggerElement);
		triggerHandler.addEventListener("click", function () {
			if(elemHandler.style.visibility === ""){
				elemHandler.style.transitionProperty = "visibility, position";
				elemHandler.style.transitionDuration = .35 + 's';
				elemHandler.style.transitionDelay = .35 + 's';
				elemHandler.style.transitionTimingFunction = "ease-in-out";
				elemHandler.style.visibility = 'visible';
				elemHandler.style.transform = "scale(" + 1 + ")";
			}
			else if(elemHandler.style.visibility === "visible"){
				elemHandler.style.transitionProperty = "visibility, transform, position";
				elemHandler.style.transitionDuration = .2 + 's';
				elemHandler.style.transitionDelay = .05 + 's';
				elemHandler.style.visibility = 'hidden';
				elemHandler.style.position = 'fixed';
				elemHandler.style.transitionTimingFunction = "linear";
			}
			else if(elemHandler.style.visibility === "hidden"){
				elemHandler.style.transitionProperty = "visibility, position";
				elemHandler.style.transitionDuration = .35 + 's';
				elemHandler.style.transitionDelay = .35 + 's';
				elemHandler.style.transitionTimingFunction = "ease-in-out";
				elemHandler.style.visibility = 'visible';
				elemHandler.style.transform = "scale(" + 1 + ")";
			}
		})
	}
	this.borderHover = (elements) =>{
		elements.forEach((index, value) =>{
			let elementGetter = document.querySelector(elements[value]);
			elementGetter.addEventListener('mouseover', ()=>{
				elementGetter.style.border = '3px solid #5576fc'; 
			});
			elementGetter.addEventListener('mouseout', ()=>{
				elementGetter.style.border = 'none'; 
			});
		});
	}
}
/*Code for events that Happen When you click the start button ENDS here*/

 

 function tooltip(element, attribute, container, text, triggerElement){
 		let triggerElementH = document.querySelector(triggerElement);
 		let element2 = document.createElement(element);//The created element
		let container2 = document.querySelector(container);
		let attribute2 = element2.setAttribute(attribute.name,  attribute.value);
		element2.innerHTML = text;
		container2.appendChild(element2);
 		triggerElementH.addEventListener('mouseover', ()=>{
 			if(element2.style.visibility === "hidden"){
 				element2.style.transitionProperty = "visibility";
				element2.style.transitionDuration = .3 + 's';
				element2.style.transitionDelay = .8 + 's';
				element2.style.visibility = 'visible';
 				if(triggerElementH.className === "documents"){
 					element2.style.left = 25.8 + '%';
	 				element2.style.top = 59.8 + '%';			
				}
				else if(triggerElementH.className === "pictures"){
 					element2.style.left = 35.8 + '%';
	 				element2.style.top = 59.8 + '%';			
				}
				else if(triggerElementH.className === "folder2"){
 					element2.style.left = 60.8 + '%';
	 				element2.style.top = 32.8 + '%';			
				}
				else if(triggerElementH.className === "folder1"){
	 				element2.style.left = 50.8 + '%';
	 				element2.style.top = 32.8 + '%';			
				}
				else if(triggerElementH.className === "pcSettings"){
 					element2.style.left = 35.8 + '%';
	 				element2.style.top = 45.8 + '%';			
				}
				else if(triggerElementH.className === "thisPc"){
 					element2.style.left = 25.8 + '%';
	 				element2.style.top = 45.8 + '%';			
				}
				else if(triggerElementH.className === "camera"){
 					element2.style.left = 60.8 + '%';
	 				element2.style.top = 20.8 + '%';			
				}
				else if(triggerElementH.className === "xbox"){
 					element2.style.left = 50.8 + '%';
	 				element2.style.top = 20.8 + '%';			
				}
			}
 		});
 		triggerElementH.addEventListener('mouseout', ()=>{
			if(element2.style.visibility === "visible"){
				element2.style.transitionProperty = "visibility";
				element2.style.transitionDuration = .24 + 's';
				element2.style.transitionDelay = .2 + 's';
				element2.style.visibility = 'hidden';
			}
 		});
}

function signOutConstructor(){
	let appPic = "Change account picture";
	let lock = "lock";
	let signout = "signout";
	return "<div class='accPic' style='height:20%; padding-left:8px;padding-top:7%; '>" + appPic + "</div>" + 
			"<div class='lock' style='height:20%; padding-left:8px;padding-top:7%; '>" + lock + "</div>" + 
			"<div class='signout' style='height:20%; padding-top:7%; padding-left:8px;'>" + signout + "</div>" + 
			"<hr style='width:90%;'>";
}
function Popups(){
	this.border = "border: 3px solid #2d2d2d; ";
	this.position = "position: absolute; ";
	this.zIndex = 'z-index: 200; ';
	this.visibility = 'visibility: hidden; ';
	this.transition = 'transition: visibility .2s ease-in-out 0.05s; ';
	this.bgColor = 'background-color:ghostwhite;';
	this.color = 'color:#333;';
	this.width ='width:100px; ';
	this.height ='height:100px;';
	this.right ='right:60px;';
	this.top ='top:75px;',
	this.fontSize ='font-size:15px;';
	this.padding ='padding:0;';
	this.fontWeigh ='font-weight:bold '; 
	this.getValue = () =>{
		return this.border +  this.position + this.zIndex + this.visibility + this.transition
		+ this.bgColor + this.color + this.width + this.height + this.right+ this.top + this.fontSize
		+ this.padding + this.fontWeight;
	}
	this.powerBtnConstructor = () =>{
		let sleep = "Sleep";
		let shutdown = "Shutdown";
		let restart = "Restart";
		return "<div class='powerItems' style='height:20%; padding-left:8px;padding-top:7%; '>" + sleep + "</div>" + 
				"<div class='powerItems' style='height:20%; padding-left:8px;padding-top:7%; '>" + shutdown + "</div>" + 
				"<div class='powerItems' style='height:20%; padding-top:7%; padding-left:8px;'>" + restart + "</div>";
	}
	this.searchConstructor = () =>{
		return "<div style='color:ghostwhite;width:90%; margin-left:10px;'>Search</div>" + 
				"<input type='text' autofocus='true' style='display:block;width:90%;height:20px; margin:10px 0 0 13.67px;'>"
	}
	this.powerBtnPopup = (triggerElement)=>{
		let triggerVar = document.querySelector(triggerElement);
		let element = document.createElement('div');
		let container = document.querySelector('.header-container');
		element.setAttribute('style', this.getValue());
		element.setAttribute('class', "powerBtnPopup");
		element.innerHTML = this.powerBtnConstructor();
		container.appendChild(element);
		let elem = document.querySelector('.powerBtnPopup');
		triggerVar.addEventListener('click', ()=>{
			setTimeout(toogleIn, 270);
		});
		window.addEventListener('click', toggleOut);
		window.addEventListener('mousemove', (e)=>{
			if((e.clientX >=1146 && e.clientX <= 1261) && (e.clientY >= 25 && e.clientY <= 180)){
				window.removeEventListener('click', toggleOut);
			}
			else if((e.clientX < 1146 || e.clientX > 1261) || (e.clientY <= 24 || e.clientY >= 181)){
				window.addEventListener('click', toggleOut);
			}
		});
		function toggleOut(){	
			elem.style.visibility = 'hidden';
		}
		function toogleIn(){
			if(elem.style.visibility === 'visible'){
				elem.style.visibility = 'hidden';
			}
			else if(elem.style.visibility === 'hidden'){
				elem.style.visibility = 'visible';
			}
		}
	}
	this.searchStyles =()=>{
		return "color: ghostwhite;background-color: #1f115f;z-index: 1000;visibility: hidden; "+
		"height: 100%;width: 20%;position: absolute;right: 0px;top: 0px;bottom: 0; " + 
		"transform:translateX(273.188px); transition: visibility, transform .09s ease-in-out 0s;" + 
		"padding:25px 1% 0;";
	}
	this.searchPopup = (triggerElement) =>{
		let triggerVar = document.querySelector(triggerElement);
		let element = document.createElement('div');
		let container = document.querySelector('.main-content');
		element.setAttribute('style', this.searchStyles());
		element.setAttribute('class', "searchPopup");
		element.innerHTML = this.searchConstructor();
		container.appendChild(element);
		let elem = document.querySelector('.searchPopup');
		triggerVar.addEventListener('click', ()=>{
			setTimeout(toogleIn, 500);
		});
		window.addEventListener('mousemove', (e)=>{
			if(e.clientX <= 1055){
				window.addEventListener('click', toggleOut);
			}
			else if(e.clientX > 1055 ){
				window.removeEventListener('click', toggleOut);
			}
		});
		function toggleOut(){	
			//elem.style.visibility = 'hidden';
			elem.style.transform = 'translateX(' + 298.818 + 'px)';
		}
		function toogleIn(){
			window.removeEventListener('click', toggleOut);
			if(elem.style.visibility === 'visible'){
				//elem.style.visibility = 'hidden';
				elem.style.transform = 'translateX(' + 0 + ')';
			}
			if(elem.style.visibility === 'hidden'){
				elem.style.visibility = 'visible';
				elem.style.transform = 'translateX(' + 0 + ')';
			}
		}
	}
}

function signoutPopUp(triggerElement){
	let signoutAtrribute = {
	border: "border: 3px solid #2d2d2d; ",
	position: "position: absolute; ",
	zIndex: 'z-index: 200; ',
	visibility: 'visibility: hidden; ',
	transition: 'transition: visibility .09s ease-in-out 0s; ',
	bgColor: 'background-color:ghostwhite;',
	color: 'color:#333;',
	width:'width:200px; ',
	height:'height:205px;',
	right:'right:160px;',
	top:'top:75px;',
	fontSize:'font-size:15px;',
	padding:'padding:0;',
	fontWeight:'font-weight:bold ', 
	getValue: function(){
			return this.border +  this.position + this.zIndex + this.visibility + this.transition
			+ this.bgColor + this.color + this.width + this.height + this.right+ this.top + this.fontSize
			+ this.padding + this.fontWeight;
		}
	}
	let accH = document.querySelector(triggerElement);
	let element = document.createElement('div');
	let container = document.querySelector('.header-container');
	element.setAttribute('style', signoutAtrribute.getValue());
	element.setAttribute('class', "signoutPopUp");
	element.innerHTML = signOutConstructor();
	container.appendChild(element);
	let elem = document.querySelector('.signoutPopUp');
	accH.addEventListener('click', ()=>{
		setTimeout(toogleIn, 270);
	});
	window.addEventListener('click', toggleOut);
	window.addEventListener('mousemove', (e)=>{
		if((e.clientX >=948 && e.clientX <= 1157) && (e.clientY >= 74 && e.clientY <= 287)){
			window.removeEventListener('click', toggleOut);
		}
		else if((e.clientX < 948 || e.clientX > 1157) || (e.clientY < 74 || e.clientY > 287)){
			window.addEventListener('click', toggleOut);
		}
		if(e.clientX >= 1056  && e.clientX <= 1155){
			if(e.clientY >= 25 && e.clientY <= 74){
				window.addEventListener('click', toggleOut);
			}
		}
	});
	function toggleOut(){	
		elem.style.visibility = 'hidden';
	}
	function toogleIn(){
		window.removeEventListener('click', toggleOut);
		if(elem.style.visibility === 'visible'){
			elem.style.visibility = 'hidden';
		}
		else if(elem.style.visibility === 'hidden'){
			elem.style.visibility = 'visible';
		}
	}
}
let notification = new ActionCenter('.action_center div#notification div#contain', '#notification .overlay');
let pcIssues = new ActionCenter('#pcIssues', '#pcIssues .overlay');
let battery = new ActionCenter('#power', '#power .overlay');
let wifi = new ActionCenter('#conn', '#conn .overlay');
let volumes = new ActionCenter('#vol', '#vol .overlay');
let date = new ActionCenter('#time', '#time .overlay');
volumes.showHideIcons('volume');
pcIssues.showHideIcons('flag');
notification.showHideIcons('notification');
battery.showHideIcons('battery');
wifi.showHideIcons('wifi');
date.showHideIcons('date');
function ActionCenter(triggerElement, affectedElement){
	this.triggerElement = triggerElement;
	this.affectedElement = affectedElement;
	let trigElem = document.querySelector(triggerElement);
	let affectElem = document.querySelector(affectedElement);
	let tooltip = document.querySelector('#tooltip');
	this.showHideIcons = (actionElem) =>{
		trigElem.addEventListener('mouseover', ()=>{
			if(actionElem === 'notification'){
				affectElem.style.backgroundColor = '#ffffff';
				affectElem.style.opacity = .5;
				affectElem.style.border = '1px solid #000000';
				affectElem.style.visibility = 'visible';
				setTimeout(()=>{
					this.mouseOver(actionElem);
				}
				, 500);
			}
			else if(actionElem === "flag"){
				flag.style.borderLeft = ".5px solid rgba(200, 200, 200, .5)";
				flag.style.borderRight = ".5px solid rgba(200, 200, 200, .5)";
				affectElem.style.backgroundColor = 'transparent';
				affectElem.style.visibility = 'visible';
				setTimeout(()=>{
						this.mouseOver(actionElem);
					}
					, 500);
			}
			else if(actionElem === "battery"){
				power.style.borderLeft = ".5px solid rgba(200, 200, 200, .5)";
				power.style.borderRight = ".5px solid rgba(200, 200, 200, .5)";
				affectElem.style.backgroundColor = 'transparent';
				affectElem.style.visibility = 'visible';
				setTimeout(()=>{
						this.mouseOver(actionElem);
					}
					, 500);
			}
			else if(actionElem === "wifi"){
				conn.style.borderLeft = ".5px solid rgba(200, 200, 200, .5)";
				conn.style.borderRight = ".5px solid rgba(200, 200, 200, .5)";
				affectElem.style.backgroundColor = 'transparent';
				affectElem.style.visibility = 'visible';
				setTimeout(()=>{
						this.mouseOver(actionElem);
					}
					, 500);
			}
			else if(actionElem === "volume"){
				vol.style.borderLeft = ".5px solid rgba(200, 200, 200, .5)";
				vol.style.borderRight = ".5px solid rgba(200, 200, 200, .5)";
				affectElem.style.backgroundColor = 'transparent';
				affectElem.style.visibility = 'visible';
				setTimeout(()=>{
						this.mouseOver(actionElem);
					}
					, 500);
			}
			else if(actionElem === "date"){
				time.style.borderLeft = ".5px solid rgba(200, 200, 200, .5)";
				time.style.borderRight = ".5px solid rgba(200, 200, 200, .5)";
				affectElem.style.backgroundColor = 'transparent';
				affectElem.style.visibility = 'visible';
				setTimeout(()=>{
						this.mouseOver(actionElem);
					}
					, 500);
			}
		});
		trigElem.addEventListener('mouseout', ()=>{
			clearTimeout(this.mouseOver);
			this.mouseOut();
		});
	}
	let time = document.querySelector('#time');
	let flag = document.querySelector('#flag');
	let power = document.querySelector('#battery');
	let conn = document.querySelector('#wifi');
	let vol = document.querySelector('#sounds');
	this.mouseOut = () =>{
		flag.style.border = "none";
		power.style.border = "none";
		conn.style.border = "none";
		affectElem.style.visibility = 'hidden';
		tooltip.style.visibility = 'hidden';
	}
	this.mouseOver = (actionElem)=>{
		if(actionElem === "flag"){
			tooltip.style.right = "100px";
			tooltip.style.bottom = '25px';
			tooltip.innerHTML = "Solve PC Issues";
		}
		else if(actionElem === "notification"){
			tooltip.style.right = "150px";
			tooltip.style.bottom = '25px';
			tooltip.innerHTML = "Show hidden icons";
		}
		else if(actionElem === "battery"){
			tooltip.style.right = "75px";
			tooltip.style.bottom = '25px';
			tooltip.innerHTML = "Fully Charged (100%)";
		}
		else if(actionElem === "wifi"){
			tooltip.style.right = "50px";
			tooltip.style.bottom = '25px';
			tooltip.innerHTML = "Connected";
		}
		else if(actionElem === "volume"){
			tooltip.style.right = "25px";
			tooltip.style.bottom = '25px';
			tooltip.innerHTML = "Speaker: 100%";
		}
		else if(actionElem === "date"){
			tooltip.style.right = "5px";
			tooltip.style.bottom = '25px';
			tooltip.innerHTML = "Tue March 19, 2019";
		}
		tooltip.style.visibility = 'visible';
		tooltip.style.fontSize = '11.5px';
		tooltip.style.backgroundColor = "#ffffff";
		tooltip.style.padding = '3px';
		tooltip.style.textAlign = "center";
		tooltip.style.transition = 'visibility .3s ease-in-out .1s';
	}
}
window.addEventListener('load', ()=>{
	let root = document.querySelector('#content-grid');
	let scrRemove = document.querySelector('script');
	let elemParent = document.createElement('div');
	let elemChild = document.createElement('div');
	
	if((window.innerWidth < 1281 && window.innerHeight < 517) || (window.innerWidth < 1281 || window.innerHeight < 517)){
		//root.style.display = 'none';
		document.body.removeChild(root);
		scrRemove.removeAttribute('src');
		elemChild.innerHTML = "Unfortunately, this web page was not designed to be responsive " +
		"if you see this message you are either you using a smartphone, resized your browser or using devices " +
		 "with smaller screen. Logically windows 8 front display for desktop wasn't created to be scallable for " + 
		 "smaller screens..however as a web development challenge " + "I dare you to make this web page mobile first and " + 
		 " responsive"  + "<div style='color:green'>resize your browser to full size then click restore</div>";
		elemChild.setAttribute('style', 'font-family:sans-serif;font-size:30px;margin:0 50px 0;');
		elemParent.setAttribute('id', 'rootError');
		elemParent.setAttribute('style', 'display:flex; align-items:center;justify-content:center;text-align:center;color:#aa0000;');
		document.body.appendChild(elemParent);
		let elP = document.getElementById('rootError');
		let btn = document.createElement('button');
		btn.setAttribute('style', 'display:block;margin:0 auto;');
		btn.innerHTML = "Restore";
		elP.appendChild(elemChild);
		document.body.appendChild(btn);
		btn.onclick = ()=>{
			location.reload();
		}
	}
	window.addEventListener('resize', ()=>{
		if((window.innerWidth < 1281 && window.innerHeight < 517) || (window.innerWidth < 1281 || window.innerHeight < 517)){
			//root.style.display = 'none';
			document.body.removeChild(root);
			scrRemove.removeAttribute('src');
			elemChild.innerHTML = "Unfortunately, this web page was not designed to be responsive " +
			"if you see this message you are either you using a smartphone, resized your browser or using devices " +
			 "with smaller screen. Logically windows 8 front display for desktop wasn't created to be scallable for " + 
			 "smaller screens..however as a web development challenge " + "I dare you to make this web page mobile first and " + 
			 " responsive " + "<div style='color:green'>resize your browser to full size then click restore</div>";
			elemChild.setAttribute('style', 'font-family:sans-serif;font-size:30px;text-align:center;margin:0 50px 0');
			elemParent.setAttribute('id', 'rootError');
			elemParent.setAttribute('style', 'display:flex; align-items:center;justify-content:center; color:#aa0000;');
			document.body.appendChild(elemParent);
			let elP = document.getElementById('rootError');
			let btn = document.createElement('button');
			btn.setAttribute('style', 'display:block;margin:0 auto;');
			btn.innerHTML = "Restore";
			document.body.appendChild(elemChild);
			document.body.appendChild(btn);
			btn.onclick = ()=>{
				location.reload();
			}
		}
		
	});
});
	